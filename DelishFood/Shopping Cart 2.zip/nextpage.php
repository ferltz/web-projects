<?php
echo "<h1>Congratulations, your order has been submitted!</h1>";
echo "Your order total is: &euro;" . $_COOKIE['Total'];
echo "<h2>Your order will be despatched in the next 5 working days</h2>";
?>